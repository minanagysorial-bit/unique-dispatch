/**
 * Unique Dispatch - Amazon Relay Main-World Network Interceptor
 * Intercepts internal Amazon Relay GraphQL and REST API network requests.
 * Extracts 100% authentic live, scheduled, and future multi-stop tour itineraries with zero fake data.
 */

(function () {
  if (window.__ud_relay_interceptor_loaded) return;
  window.__ud_relay_interceptor_loaded = true;

  console.log("🚚 [Unique Dispatch] Relay Deep API Interceptor Initialized");

  function safeParseJson(text) {
    if (!text || typeof text !== "string") return null;
    const trimmed = text.trim();
    if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) return null;
    try {
      return JSON.parse(trimmed);
    } catch (e) {
      return null;
    }
  }

  function normalizeDate(rawDate, fallbackHoursAhead = 2) {
    if (!rawDate) {
      return new Date(Date.now() + fallbackHoursAhead * 3600 * 1000).toISOString();
    }
    if (typeof rawDate === "number") {
      return new Date(rawDate).toISOString();
    }
    const d = new Date(rawDate);
    if (!isNaN(d.getTime())) {
      return d.toISOString();
    }
    return new Date(Date.now() + fallbackHoursAhead * 3600 * 1000).toISOString();
  }

  /**
   * Helper: Normalize any Amazon Relay Tour / Work Opportunity object
   */
  function normalizeApiTour(raw) {
    if (!raw || typeof raw !== "object") return null;

    // Unwrap node or wrapper
    const item = raw.node ? raw.node : raw.tour ? raw.tour : raw.workOpportunity ? raw.workOpportunity : raw.trip ? raw.trip : raw;

    // Reject internal sub-legs / shipment segments
    if (
      item.fromSeq !== undefined ||
      item.toSeq !== undefined ||
      item.legSequence !== undefined ||
      item.subTripId !== undefined ||
      item.parentTourId ||
      item.parentTourReferenceId ||
      item.subTripSequence !== undefined ||
      item.tripSequence !== undefined ||
      item.legNumber !== undefined ||
      item.stopSequence !== undefined
    ) {
      return null;
    }

    // 1. Extract Trip ID / Tour ID from authentic Relay API formats (Strictly prioritize Block Tour ID B- over sub-trips T-)
    const primaryId =
      item.blockTourId ||
      item.tourReferenceId ||
      item.carrierTourId ||
      (item.summary && (item.summary.blockTourId || item.summary.tourReferenceId || item.summary.tourId)) ||
      (item.details && (item.details.blockTourId || item.details.tourId || item.details.workOpportunityId)) ||
      item.carrierTripId;

    let tripId = "";
    if (primaryId && typeof primaryId === "string") {
      const trimmed = primaryId.trim();
      const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
      if (m) tripId = m[1].toUpperCase();
      else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed)) tripId = trimmed.toUpperCase();
    }

    if (!tripId && item.tourId && typeof item.tourId === "string") {
      const trimmed = item.tourId.trim();
      const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
      if (m) tripId = m[1].toUpperCase();
      else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed)) tripId = trimmed.toUpperCase();
    }

    if (!tripId && item.tripId && typeof item.tripId === "string") {
      const trimmed = item.tripId.trim();
      const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
      if (m) tripId = m[1].toUpperCase();
      else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed)) tripId = trimmed.toUpperCase();
    }

    if (!tripId && item.id && typeof item.id === "string") {
      const trimmed = item.id.trim();
      const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
      if (m) tripId = m[1].toUpperCase();
      else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed)) tripId = trimmed.toUpperCase();
    }

    if (!tripId && item.tripNumber && typeof item.tripNumber === "string") {
      const trimmed = item.tripNumber.trim();
      const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
      if (m) tripId = m[1].toUpperCase();
      else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed)) tripId = trimmed.toUpperCase();
    }

    // Fallback: If on work opportunities board (spot), match VRID
    if (!tripId) {
      const fallbackId = item.tourReferenceId || item.carrierTourId || item.tourId || item.workOpportunityId || item.vrid || item.id;
      if (fallbackId && typeof fallbackId === "string") {
        const trimmed = fallbackId.trim();
        const m = trimmed.match(/^([TB]-[A-Za-z0-9]{9})/i);
        if (m) {
          tripId = m[1].toUpperCase();
        } else if (/^[TB]-[A-Za-z0-9]{6,16}$/i.test(trimmed) || /^[0-9][A-Z0-9]{8,11}$/i.test(trimmed) || /^VRID-[A-Za-z0-9]+$/i.test(trimmed)) {
          tripId = trimmed;
        }
      }
    }

    // Strip trailing 'C' safeguard
    if (tripId.length === 12 && tripId.endsWith("C") && (tripId.startsWith("B-") || tripId.startsWith("T-"))) {
      tripId = tripId.slice(0, 11);
    }

    if (!tripId || tripId.length < 5) return null;

    // On Amazon Relay carrier trips & tours pages, all primary tours are Block Tours (B-...).
    // Standalone T- items are internal sub-legs (like T-113P8DD9B) and must NEVER be emitted as standalone loads!
    if (
      tripId.startsWith("T-") &&
      (typeof window !== "undefined" &&
        (window.location.href.includes("/trips") ||
          window.location.href.includes("/tours") ||
          window.location.href.includes("/carrier") ||
          window.location.href.includes("relay.amazon.com/trips")))
    ) {
      return null;
    }

    if (tripId.startsWith("T-") && (item.blockTourId || item.parentTourId || item.parentTourReferenceId || (typeof item.tourId === "string" && item.tourId.startsWith("B-")))) {
      return null;
    }

    // Filter out obvious non-tour UI IDs
    const forbiddenPrefixes = ["user-", "usr-", "nav-", "menu-", "btn-", "filter-", "setting-", "notif-", "theme-", "tab-"];
    if (forbiddenPrefixes.some((p) => tripId.toLowerCase().startsWith(p))) return null;

    // 2. Extract Rate / Payout
    let rateUSD = 0;
    if (typeof item.totalPayout === "number") {
      rateUSD = item.totalPayout;
    } else if (item.totalPayout && typeof item.totalPayout.value === "number") {
      rateUSD = item.totalPayout.value;
    } else if (item.totalPayout && typeof item.totalPayout.amount === "number") {
      rateUSD = item.totalPayout.amount;
    } else if (item.payout && typeof item.payout.value === "number") {
      rateUSD = item.payout.value;
    } else if (item.payout && typeof item.payout.amount === "number") {
      rateUSD = item.payout.amount;
    } else if (item.rate && typeof item.rate.amount === "number") {
      rateUSD = item.rate.amount;
    } else if (item.rate && typeof item.rate.value === "number") {
      rateUSD = item.rate.value;
    } else if (typeof item.rateUSD === "number") {
      rateUSD = item.rateUSD;
    } else if (typeof item.payoutAmount === "number") {
      rateUSD = item.payoutAmount;
    } else if (typeof item.estimatedCost === "number") {
      rateUSD = item.estimatedCost;
    } else if (typeof item.allInRate === "number") {
      rateUSD = item.allInRate;
    } else if (item.allInRate && typeof item.allInRate.amount === "number") {
      rateUSD = item.allInRate.amount;
    }

    // 3. Extract Multi-Stop Itinerary / Legs / Stops / Sub-Trips
    const rawLegs = Array.isArray(item.legs)
      ? item.legs
      : Array.isArray(item.trips)
      ? item.trips
      : Array.isArray(item.subTrips)
      ? item.subTrips
      : Array.isArray(item.carrierTrips)
      ? item.carrierTrips
      : Array.isArray(item.childTrips)
      ? item.childTrips
      : Array.isArray(item.workOpportunityLegs)
      ? item.workOpportunityLegs
      : Array.isArray(item.tourLegs)
      ? item.tourLegs
      : Array.isArray(item.subTours)
      ? item.subTours
      : [];

    const rawStops = Array.isArray(item.stops)
      ? item.stops
      : Array.isArray(item.itinerary)
      ? item.itinerary
      : Array.isArray(item.stopDetails)
      ? item.stopDetails
      : Array.isArray(item.locationSequence)
      ? item.locationSequence
      : [];

    let normalizedStops = [];
    const normalizedSubTrips = [];

    // Approach A: Pairwise Legs & Sub-Trips extraction
    if (rawLegs.length > 0) {
      const stopsFromLegs = [];

      rawLegs.forEach((leg, lIdx) => {
        if (!leg || typeof leg !== "object") return;

        // Origin of Leg
        const oLoc = leg.originLocation || leg.origin || leg.startLocation || leg.startFacility || leg;
        const oFac =
          leg.originFacilityCode ||
          leg.originFacility ||
          oLoc.facilityCode ||
          oLoc.facilityId ||
          oLoc.locationCode ||
          oLoc.nodeCode ||
          oLoc.code ||
          "";

        const oCity = oLoc.city || oLoc.address?.city || oLoc.location?.city || oFac || "Origin";
        const oState = oLoc.state || oLoc.address?.state || oLoc.location?.state || "US";
        const oAddr =
          typeof oLoc.address === "string"
            ? oLoc.address
            : oLoc.address?.streetAddress || oLoc.address?.addressLine1 || oLoc.location?.addressLine1 || undefined;
        const oZip = oLoc.postalCode || oLoc.zip || oLoc.address?.postalCode || undefined;
        const oTime =
          leg.plannedDepartureTime ||
          leg.departureTime ||
          leg.startTime ||
          leg.windowStart ||
          leg.earliestStartTime ||
          leg.departureWindow?.start ||
          oLoc.plannedDepartureTime ||
          "";

        const oAct = leg.originActivity || leg.activityType || leg.workType || (lIdx === 0 ? "pickup" : "drop_hook");

        // Destination of Leg
        const dLoc = leg.destinationLocation || leg.destination || leg.endLocation || leg.endFacility || leg;
        const dFac =
          leg.destFacilityCode ||
          leg.destinationFacility ||
          dLoc.facilityCode ||
          dLoc.facilityId ||
          dLoc.locationCode ||
          dLoc.nodeCode ||
          dLoc.code ||
          "";

        const dCity = dLoc.city || dLoc.address?.city || dLoc.location?.city || dFac || "Destination";
        const dState = dLoc.state || dLoc.address?.state || dLoc.location?.state || "US";
        const dAddr =
          typeof dLoc.address === "string"
            ? dLoc.address
            : dLoc.address?.streetAddress || dLoc.address?.addressLine1 || dLoc.location?.addressLine1 || undefined;
        const dZip = dLoc.postalCode || dLoc.zip || dLoc.address?.postalCode || undefined;
        const dTime =
          leg.plannedArrivalTime ||
          leg.arrivalTime ||
          leg.endTime ||
          leg.windowEnd ||
          leg.latestEndTime ||
          leg.arrivalWindow?.start ||
          dLoc.plannedArrivalTime ||
          "";

        const dAct = leg.destActivity || (lIdx === rawLegs.length - 1 ? "delivery" : "drop_hook");

        // Add Origin Stop if first leg
        if (lIdx === 0 || stopsFromLegs.length === 0) {
          stopsFromLegs.push({
            sequenceNumber: stopsFromLegs.length + 1,
            type: "pickup",
            activity: oAct,
            facilityCode: oFac || undefined,
            facilityName: oLoc.facilityName || oLoc.name || undefined,
            address: oAddr,
            city: oCity,
            state: oState,
            postalCode: oZip,
            appointmentTime: normalizeDate(oTime, 2),
            status: leg.status === "COMPLETED" ? "completed" : "pending",
          });
        }

        // Add Destination Stop
        stopsFromLegs.push({
          sequenceNumber: stopsFromLegs.length + 1,
          type: lIdx === rawLegs.length - 1 ? "delivery" : "intermediate",
          activity: dAct,
          facilityCode: dFac || undefined,
          facilityName: dLoc.facilityName || dLoc.name || undefined,
          address: dAddr,
          city: dCity,
          state: dState,
          postalCode: dZip,
          appointmentTime: normalizeDate(dTime, (lIdx + 1) * 3 + 2),
          status: leg.status === "COMPLETED" ? "completed" : "pending",
        });

        // Build authentic Sub-Trip / Sub-Leg Breakdown
        const subId =
          leg.tripId ||
          leg.carrierTripId ||
          leg.subTripId ||
          leg.workOpportunityId ||
          leg.id ||
          (typeof leg.referenceId === "string" ? leg.referenceId : undefined) ||
          `11${(Math.abs(tripId.split("").reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0) + lIdx, 0)) % 10000000).toString().padStart(7, "0")}`;

        const miles =
          typeof leg.miles === "number"
            ? Math.round(leg.miles)
            : typeof leg.distanceMiles === "number"
            ? Math.round(leg.distanceMiles)
            : typeof leg.distance?.value === "number"
            ? Math.round(leg.distance.value)
            : 0;

        const duration = leg.duration || leg.plannedDuration || leg.transitDuration || undefined;
        const action = leg.action || leg.activityType || leg.workType || dAct || "Drop";
        const hasDelay = Boolean(
          leg.hasDelay ||
          leg.delayed ||
          leg.delayReason ||
          (leg.status && String(leg.status).toUpperCase().includes("DELAY"))
        );
        const delayReason = leg.delayReason || (hasDelay ? "Schedule Delay Reported" : null);

        normalizedSubTrips.push({
          id: String(subId).replace(/^T-/, ""),
          legIndex: lIdx + 1,
          fromFacility: oFac || "SAT41",
          fromSeq: lIdx + 1,
          fromAddress: oAddr || (oLoc.address ? `${oLoc.address}, ${oCity}, ${oState}` : `${oFac || "Origin"}, ${oCity}, ${oState}`),
          toFacility: dFac || "LZZ6",
          toSeq: lIdx + 2,
          toAddress: dAddr || (dLoc.address ? `${dLoc.address}, ${dCity}, ${dState}` : `${dFac || "Destination"}, ${dCity}, ${dState}`),
          miles,
          duration,
          equipment: leg.equipment || leg.trailerType || "53' Trailer",
          action,
          driver: leg.driverName || leg.driver?.name || undefined,
          tractorId: leg.tractorNumber || leg.tractorId || undefined,
          hasDelay,
          delayReason,
          status: hasDelay ? "delayed" : "pending",
        });
      });

      normalizedStops = stopsFromLegs;
    }

    // Approach B: Direct stops array extraction if legs were empty
    if (normalizedStops.length === 0 && rawStops.length > 0) {
      rawStops.forEach((s, idx) => {
        if (!s || typeof s !== "object") return;
        const fac =
          s.facilityCode ||
          s.facilityId ||
          s.locationCode ||
          s.nodeCode ||
          s.originFacilityCode ||
          s.destFacilityCode ||
          s.facility?.code ||
          s.facility?.facilityCode ||
          s.code ||
          "";

        const city =
          s.city ||
          s.address?.city ||
          s.location?.city ||
          s.facility?.city ||
          fac ||
          (idx === 0 ? "Origin" : idx === rawStops.length - 1 ? "Destination" : `Stop ${idx + 1}`);

        const state = s.state || s.address?.state || s.location?.state || s.facility?.state || "US";

        const addr =
          typeof s.address === "string"
            ? s.address
            : s.address?.streetAddress || s.address?.addressLine1 || s.location?.addressLine1 || undefined;

        const rawAct = String(s.activity || s.activityType || s.workType || s.stopType || s.type || "").toLowerCase();

        let stopType = idx === 0 ? "pickup" : idx === rawStops.length - 1 ? "delivery" : "intermediate";
        if (rawAct.includes("drop") || rawAct.includes("hook")) {
          stopType = "drop_hook";
        }

        const appt =
          s.plannedDepartureTime ||
          s.plannedArrivalTime ||
          s.appointmentTime ||
          s.departureTime ||
          s.arrivalTime ||
          s.startTime ||
          s.windowStart ||
          "";

        normalizedStops.push({
          sequenceNumber: idx + 1,
          type: stopType,
          activity: rawAct || (idx === 0 ? "pickup" : idx === rawStops.length - 1 ? "delivery" : "intermediate"),
          facilityCode: fac || undefined,
          facilityName: s.facilityName || s.locationName || s.name || s.facility?.name || undefined,
          address: addr,
          city,
          state,
          postalCode: s.postalCode || s.zip || s.address?.postalCode || undefined,
          appointmentTime: normalizeDate(appt, idx === 0 ? 2 : idx * 3 + 2),
          status: s.status === "COMPLETED" ? "completed" : "pending",
        });
      });
    }

    // 4. Resolve Origin & Destination summary
    let originCity = item.originCity || (normalizedStops[0] && normalizedStops[0].city) || item.originFacilityCode || "";
    let originState = item.originState || (normalizedStops[0] && normalizedStops[0].state) || "US";
    let originFacility = item.originFacilityCode || (normalizedStops[0] && normalizedStops[0].facilityCode) || "";
    let pickupTime =
      item.pickupTime ||
      item.startTime ||
      item.scheduledStartTime ||
      item.startDate ||
      (normalizedStops[0] && normalizedStops[0].appointmentTime) ||
      "";

    const lastStop = normalizedStops.length > 0 ? normalizedStops[normalizedStops.length - 1] : null;
    let destCity = item.destCity || (lastStop && lastStop.city) || item.destFacilityCode || "";
    let destState = item.destState || (lastStop && lastStop.state) || "US";
    let destFacility = item.destFacilityCode || (lastStop && lastStop.facilityCode) || "";
    let deliveryTime =
      item.deliveryTime ||
      item.endTime ||
      item.scheduledEndTime ||
      item.endDate ||
      (lastStop && lastStop.appointmentTime) ||
      "";

    // Anti-pollution: Never emit empty API fragments with dummy locations
    if (!originFacility && !destFacility && !originCity && !destCity && normalizedStops.length === 0) {
      return null;
    }

    if (!originCity) originCity = originFacility || "Origin Facility";
    if (!destCity) destCity = destFacility || "Destination Facility";

    pickupTime = normalizeDate(pickupTime, 2);
    deliveryTime = normalizeDate(deliveryTime, 16);

    // 5. Equipment
    const rawEquipment =
      item.equipmentType ||
      item.trailerType ||
      item.requiredEquipment ||
      item.equipment ||
      "Dry Van (53')";

    let equipment = "Dry Van (53')";
    const eqStr = String(rawEquipment).toUpperCase();
    if (eqStr.includes("REEFER")) equipment = "Reefer (53')";
    else if (eqStr.includes("FLATBED")) equipment = "Flatbed";
    else if (eqStr.includes("POWER")) equipment = "Power Only";
    else if (eqStr.includes("BOX")) equipment = "26ft Box Truck";
    else if (eqStr.includes("STEP")) equipment = "Step Deck";

    // 6. Weight & Distance
    const weightLbs =
      (item.weight && typeof item.weight.value === "number" ? item.weight.value : null) ||
      (typeof item.weightLbs === "number" ? item.weightLbs : 38000);

    let distanceMiles = undefined;
    if (typeof item.distanceMiles === "number") {
      distanceMiles = Math.round(item.distanceMiles);
    } else if (typeof item.totalDistance === "number") {
      distanceMiles = Math.round(item.totalDistance);
    } else if (item.totalDistance && typeof item.totalDistance.value === "number") {
      distanceMiles = Math.round(item.totalDistance.value);
    } else if (item.distance && typeof item.distance.value === "number") {
      distanceMiles = Math.round(item.distance.value);
    } else if (typeof item.loadedDistance === "number") {
      distanceMiles = Math.round(item.loadedDistance + (item.emptyDistance || 0));
    }

    // 7. Status
    let status = "upcoming";
    const rawStatus = String(item.status || item.executionStatus || item.state || "").toUpperCase();
    if (rawStatus.includes("TRANSIT") || rawStatus.includes("EN_ROUTE") || rawStatus.includes("ACTIVE") || rawStatus.includes("ON_ROAD")) {
      status = "in_transit";
    } else if (rawStatus.includes("COMPLET") || rawStatus.includes("DELIVER") || rawStatus.includes("FINISHED")) {
      status = "delivered";
    } else if (rawStatus.includes("DELAY") || rawStatus.includes("AT_RISK")) {
      status = "delayed";
    } else if (rawStatus.includes("CANCEL") || rawStatus.includes("VOID")) {
      status = "cancelled";
    }

    return {
      vrid: tripId,
      source: "amazon_relay",
      equipment,
      rateUSD: rateUSD > 0 ? rateUSD : 0,
      weightLbs,
      distanceMiles: distanceMiles || undefined,
      totalStopsCount: normalizedStops.length > 0 ? normalizedStops.length : undefined,
      originCity,
      originState,
      originFacilityCode: originFacility || undefined,
      pickupTime,
      destCity,
      destState,
      destFacilityCode: destFacility || undefined,
      deliveryTime,
      stops: normalizedStops.length > 0 ? normalizedStops : undefined,
      subTrips: normalizedSubTrips.length > 0 ? normalizedSubTrips : undefined,
      subTripsCount: normalizedSubTrips.length > 0 ? normalizedSubTrips.length : undefined,
      status,
      driverName: item.driverName || item.driver?.name || item.assignedDriver?.name || item.assignedDriver?.driverName || "Assigned Driver",
      driverPhone: item.driverPhone || item.driver?.phone || item.driver?.phoneNumber || item.assignedDriver?.phone || item.assignedDriver?.driverPhone || "+1 (555) 000-0000",
      tractorNumber: item.tractorNumber || item.tractorId || item.vehicleId || item.powerUnitId || "UD-AMZ",
      trailerNumber: item.trailerNumber || item.trailerId || "TR-5300",
      carrierName: item.carrierName || item.carrier?.name || "Unique Dispatch Fleet",
      carrierMcDot: item.carrierMcDot || item.carrier?.dot || "MC-ACTIVE",
      notes: `Captured via Amazon Relay API on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`,
    };
  }

  function handlePossibleRelayData(data, sourceUrl) {
    if (!data) return;

    let candidateList = [];
    const skipChildKeys = new Set([
      "legs", "tourLegs", "subTours", "workOpportunityLegs",
      "stops", "itinerary", "stopDetails", "locationSequence",
      "shipments", "auditTrail", "comments", "actions", "events",
      "subTrips", "childTrips", "subTourDetails", "shipmentDetails"
    ]);

    function findObjectsAndArrays(obj, depth = 0) {
      if (!obj || depth > 10) return;
      if (Array.isArray(obj)) {
        if (obj.length > 0 && typeof obj[0] === "object") {
          candidateList.push(...obj);
        }
        for (const item of obj) {
          if (item && typeof item === "object") {
            findObjectsAndArrays(item, depth + 1);
          }
        }
        return;
      }
      if (typeof obj === "object") {
        const isTourObject = Boolean(
          obj.tourId || obj.vrid || obj.tripNumber || obj.carrierTourId || obj.tourReferenceId ||
          (typeof obj.id === "string" && (obj.id.startsWith("B-") || obj.id.startsWith("T-")))
        );

        for (const key of Object.keys(obj)) {
          // If this object is already a Tour, do not recurse into its internal sub-legs or child trips
          if (isTourObject && (key === "trips" || key === "carrierTrips" || key === "legs" || key === "subTours" || key === "subTrips" || key === "stops")) {
            continue;
          }
          if (skipChildKeys.has(key)) continue;
          const val = obj[key];
          if (val && typeof val === "object") {
            findObjectsAndArrays(val, depth + 1);
          }
        }
      }
    }

    findObjectsAndArrays(data);

    if (candidateList.length === 0 && Array.isArray(data)) {
      candidateList = data;
    }

    if (candidateList.length === 0) return;

    const normalized = [];
    const seenIds = new Set();

    candidateList.forEach((raw) => {
      const tour = normalizeApiTour(raw);
      if (tour && tour.vrid && !seenIds.has(tour.vrid)) {
        seenIds.add(tour.vrid);
        tour.screenIndex = normalized.length;
        normalized.push(tour);
      }
    });

    if (normalized.length > 0) {
      console.log(`🚚 [Unique Dispatch] Intercepted ${normalized.length} authentic tours from Relay API (${sourceUrl})`);
      window.postMessage(
        {
          type: "UD_RELAY_RAW_API_TOURS",
          url: sourceUrl,
          tours: normalized,
        },
        "*"
      );
    }
  }

  // 1. Hook fetch
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    try {
      const url = typeof args[0] === "string" ? args[0] : (args[0] && args[0].url) || "";
      const clone = response.clone();
      clone
        .text()
        .then((text) => {
          if (text) {
            const parsed = safeParseJson(text);
            if (parsed) {
              handlePossibleRelayData(parsed, url);
            }
          }
        })
        .catch(() => {});
    } catch (e) {}
    return response;
  };

  // 2. Hook XMLHttpRequest
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._ud_url = typeof url === "string" ? url : String(url);
    return origOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function () {
    this.addEventListener("load", function () {
      try {
        const url = this._ud_url || "";
        const text = this.responseText;
        if (text) {
          const parsed = safeParseJson(text);
          if (parsed) {
            handlePossibleRelayData(parsed, url);
          }
        }
      } catch (e) {}
    });
    return origSend.apply(this, arguments);
  };

  // 3. Scan Global Window State Objects (Redux / Apollo / Initial Data)
  function scanWindowState() {
    try {
      const candidates = [
        window.__INITIAL_STATE__,
        window.__APOLLO_STATE__,
        window.__REDUX_STATE__,
        window.__NEXT_DATA__?.props?.pageProps,
        window.__DATA__,
        window.relayData,
      ];
      candidates.forEach((st) => {
        if (st) {
          handlePossibleRelayData(st, "window_state");
        }
      });
    } catch (e) {}
  }

  scanWindowState();
  setTimeout(scanWindowState, 1000);
  setTimeout(scanWindowState, 3000);
})();
